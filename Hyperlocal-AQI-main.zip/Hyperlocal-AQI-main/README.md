# Hyperlocal AQI Predictor (Bangalore - Hebbal)

A machine learning-based time-series forecasting system designed to predict the **Air Quality Index (AQI)** for the Hebbal locality in Bangalore, India. The model utilizes a 24-hour forecast horizon, leveraging historical air quality data and meteorological features to provide localised, actionable insights.

## 📌 Project Overview
Air quality in urban centres like Bangalore is highly dynamic, influenced by both local pollutant sources and specific weather patterns. This project implements a sophisticated **Stacked Ensemble** approach to forecast AQI levels 24 hours into the future. Unlike general city-wide models, this system is tuned for hyperlocal data, specifically targeting the Hebbal station parameters and calculating results based on the official **Indian CPCB standards**.

## 🚀 Key Features
* **Time-Series Forecasting:** Predicts AQI 24 hours ahead using a sliding window approach.
* **Advanced Feature Engineering:**
    * **Cyclical Time Encoding:** Transforms hour and month data into Sine/Cosine components.
    * **Wind Transport Vectors:** Converts wind speed and direction into North-South and East-West components.
    * **Lag & Rolling Statistics:** Utilises historical data (lags) and moving averages to capture trends.
* **Indian CPCB Standards:** Custom calculation of AQI based on the Indian Central Pollution Control Board (CPCB) breakpoints for PM2.5.
* **Meta-Model Architecture:** Uses a "Super Model" to blend predictions from multiple algorithms for maximum stability.

## 🛠️ Tech Stack
* **Language:** Python
* **Backend & Data:** FastAPI, SQLAlchemy, PostgreSQL
* **Machine Learning:** XGBoost, Scikit-learn (Random Forest, Linear Regression)
* **Data Processing:** Pandas, NumPy
* **Environment:** Ubuntu (WSL) / Neovim

## 📊 Dataset & Attribution
This project utilises a hybrid dataset to ensure hyperlocal accuracy for the Hebbal region:

1.  **Air Quality Data:** Sourced from the **Karnataka State Pollution Control Board (KSPCB)** via the Hebbal Monitoring Station. This includes historical PM2.5 and calculated AQI values.
2.  **Meteorological Data:** Sourced from **Open-Meteo** (Temperature, Humidity, Wind Speed/Direction, and Precipitation).

**Attributions:**
* AQI data provided by [KSPCB](https://kspcb.karnataka.gov.in/).
* Weather data provided by [Open-Meteo.com](https://open-meteo.com/) under the [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) license.

## 🏗️ Model Architecture
The data pipeline follows a structured machine learning workflow:
1.  **Data Cleaning:** Handling missing values and indexing temporal data.
2.  **AQI Transformation:** Converting raw PM2.5 concentrations into a standard AQI index using Indian national sub-index formulas.
3.  **Stacked Ensemble (The "Super Model"):** * **Level 0:** Multiple base models (XGBoost, Random Forest, and Linear Regression) are trained independently on the feature set.
    * **Level 1:** A final Meta-Learner ingests the predictions from all base models to produce the ultimate, refined AQI forecast.
4.  **Validation:** Evaluation is performed using `TimeSeriesSplit` to ensure chronological integrity.

## 💻 Setup & Installation
1.  Clone the repository:
    ```bash
    git clone [https://github.com/Tanaayaa/Hyperlocal-AQI.git](https://github.com/Tanaayaa/Hyperlocal-AQI.git)
    cd Hyperlocal-AQI
    ```
2.  Create a virtual environment and install dependencies:
    ```bash
    python -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
    ```
3.  Run the notebook:
    ```bash
    jupyter notebook AQI_Predictor.ipynb
    ```

## 📄 License
Distributed under the MIT License. See `LICENSE` for more information.

## 👤 Contact
**Tanaya** - [GitHub Profile](https://github.com/Tanaayaa)  
Project Link: [https://github.com/Tanaayaa/Hyperlocal-AQI](https://github.com/Tanaayaa/Hyperlocal-AQI)
